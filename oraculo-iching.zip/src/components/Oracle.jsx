import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Hexagram } from "./Hexagram.jsx";
import Hero from "./Hero.jsx";
import hexagrams from "../data/i-ching-basic.js";
import styles from "./Oracle.module.css";

// Índice de busca: binário visual.
const byBinary = new Map(
  hexagrams.map((h) => [String(h.binary).padStart(6, "0"), h]),
);

// Método das três moedas: cada moeda vale 2 ou 3; a soma decide a linha.
// 6 = yin mutável, 7 = yang, 8 = yin, 9 = yang mutável.
function throwCoin() {
  return Math.random() < 0.5
    ? { face: "cara", value: 3, glyph: "乾" }
    : { face: "coroa", value: 2, glyph: "坤" };
}

function buildLine() {
  const coins = [throwCoin(), throwCoin(), throwCoin()];
  const value = coins.reduce((sum, coin) => sum + coin.value, 0);
  return {
    coins,
    yang: value === 7 || value === 9,
    changing: value === 6 || value === 9,
  };
}

// Linha desenhável pelo <Hexagram> (tipo + marca de mutação).
function toDrawLine(line) {
  return { type: line.yang ? "yang" : "yin", changing: line.changing };
}

// As linhas saem de baixo para cima; o binário do dataset é de cima para baixo.
function lookupHexagram(lines) {
  const binary = lines
    .map((line) => (line.yang ? "1" : "0"))
    .reverse()
    .join("");
  return byBinary.get(binary) || null;
}

const TOTAL_LINES = 6;
const MAX_QUESTION = 280;

// Ajusta a altura do textarea ao conteúdo (cresce conforme quebra linha).
function autoGrow(el) {
  el.style.height = "auto";
  el.style.height = `${el.scrollHeight}px`;
}

export default function Oracle() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState("ask"); // "ask" | "casting"
  const [question, setQuestion] = useState("");
  const [lines, setLines] = useState([]);
  const [coins, setCoins] = useState(() => [
    throwCoin(),
    throwCoin(),
    throwCoin(),
  ]); // faces do último lançamento
  const [rolling, setRolling] = useState(false);

  const modalRef = useRef(null);

  const trimmedQuestion = question.trim();
  const remaining = MAX_QUESTION - question.length;
  const isComplete = lines.length === TOTAL_LINES;
  const result = useMemo(
    () => (isComplete ? lookupHexagram(lines) : null),
    [isComplete, lines],
  );


  // Foco vai para o modal ao abrir.
  useEffect(() => {
    if (phase === "casting") modalRef.current?.focus();
  }, [phase]);

  // Esc fecha o modal de lançamento e volta para a pergunta.
  useEffect(() => {
    if (phase !== "casting") return undefined;
    const onKey = (event) => {
      if (event.key !== "Escape") return;
      setLines([]);
      setPhase("ask");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase]);

  const handleStart = (event) => {
    event.preventDefault();
    if (!trimmedQuestion) return;
    setLines([]);
    setPhase("casting");
  };

  const handleThrow = () => {
    if (rolling || isComplete) return;
    setRolling(true);
    const nextLine = buildLine();
    window.setTimeout(() => {
      setLines((current) => [...current, nextLine]);
      setCoins(nextLine.coins);
      setRolling(false);
    }, 600);
  };

  const handleClose = () => {
    setLines([]);
    setPhase("ask");
  };

  const handleReveal = () => {
    if (!result) return;
    // Posições (1 a 6, de baixo para cima) das linhas mutáveis, ex.: "14".
    const changing = lines.map((line, i) => (line.changing ? i + 1 : "")).join("");
    const path = changing
      ? `/leitura/${result.hex}/${changing}`
      : `/leitura/${result.hex}`;
    navigate(path, { state: { question: trimmedQuestion } });
  };

  return (
    <main id="conteudo" className={styles.oracle}>
      <Hero />

      <div className={`container ${styles.consult}`}>
        <form className={styles.ask} onSubmit={handleStart}>
          <label className={styles.label} htmlFor="question">
            Qual é a sua pergunta?
          </label>
          <textarea
            id="question"
            className={styles.input}
            value={question}
            onChange={(event) => {
              setQuestion(event.target.value);
              autoGrow(event.target);
            }}
            rows={2}
            maxLength={MAX_QUESTION}
            placeholder="Ex.: Como devo lidar com a mudança que estou enfrentando?"
          />
          <p
            className={`${styles.counter} ${
              remaining <= 20 ? styles.counterLow : ""
            }`}
          >
            {question.length}/{MAX_QUESTION}
          </p>
          <button
            type="submit"
            className={styles.primary}
            disabled={!trimmedQuestion}
          >
            Lançar as moedas
          </button>
        </form>
      </div>

      {phase === "casting" && (
        <div className={styles.backdrop} onMouseDown={handleClose}>
          <div
            className={styles.modal}
            role="dialog"
            aria-modal="true"
            aria-labelledby="cast-title"
            tabIndex={-1}
            ref={modalRef}
            onMouseDown={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              className={styles.closeButton}
              onClick={handleClose}
              aria-label="Fechar e voltar à pergunta"
            >
              ✕
            </button>

            <h2 id="cast-title" className={styles.modalTitle}>
              Lance as moedas
            </h2>
            <p className={styles.modalHint}>
              Mantenha a pergunta em mente e lance as três moedas seis vezes.
            </p>

            <div className={styles.coins} aria-hidden="true">
              {coins.map((coin, index) => (
                <span
                  key={index}
                  className={`${styles.coin} ${
                    rolling ? styles.coinRolling : ""
                  } ${coin.face === "coroa" ? styles.coinTails : ""}`}
                >
                  <span className={styles.coinGlyph}>{coin.glyph}</span>
                </span>
              ))}
            </div>

            <p className={styles.progress} aria-live="polite">
              {isComplete
                ? "Hexagrama completo."
                : `${lines.length} de ${TOTAL_LINES} linhas`}
            </p>

            <div className={styles.castStage}>
              <Hexagram
                lines={lines.map(toDrawLine)}
                width={120}
                label={`Hexagrama em formação: ${lines.length} de ${TOTAL_LINES} linhas`}
              />
            </div>

            {isComplete ? (
              <button
                type="button"
                className={styles.primary}
                onClick={handleReveal}
              >
                Ver resultado
              </button>
            ) : (
              <button
                type="button"
                className={styles.primary}
                onClick={handleThrow}
                disabled={rolling}
              >
                {rolling ? "Girando…" : "Lançar"}
              </button>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
